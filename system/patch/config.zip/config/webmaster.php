<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['version']      = '1.0.1';
$config['Aauthor']      = 'Not Found dot ID';
$config['sistem']       = 'https://notfound.id';
$config['email']        = 'matadata.dev2021@gmail.com';
