<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-05 05:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 11:23:26 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-05 06:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 06:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 09:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 14:50:08 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-05 09:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 09:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 09:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 10:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 10:29:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-05 15:29:26 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-05 10:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
