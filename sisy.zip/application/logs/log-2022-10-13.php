<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-13 04:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 04:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:39:42 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-13 04:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 04:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 04:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 04:52:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 04:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 04:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:06:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:38:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:53:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:54:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:54:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:55:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 05:55:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:13:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `atas_nama` IS NULL
AND `no_rek` < `IS` `NULL`' at line 5 - Invalid query: SELECT *
FROM `dt_siswa`
JOIN `mt_provinsi` ON `mt_provinsi`.`id_provinsi` = `dt_siswa`.`provinsi_id`
JOIN `mt_kabupaten` ON `mt_kabupaten`.`id_kabupaten` = `dt_siswa`.`kabupaten_id`
WHERE `nisn` > `IS` `NULL`
AND `atas_nama` IS NULL
AND `no_rek` < `IS` `NULL`
ERROR - 2022-10-13 06:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:13:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:13:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:28:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:29:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:30:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:30:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:30:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:31:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:31:03 --> 404 Page Not Found: Satpen/index
ERROR - 2022-10-13 06:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:31:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:31:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:32:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:32:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 06:32:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 14:16:11 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-13 09:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 14:19:24 --> Severity: Notice --> Undefined variable: siswa C:\xampp\htdocs\sisy\application\views\master\verval_siswa.php 82
ERROR - 2022-10-13 14:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sisy\application\views\master\verval_siswa.php 82
ERROR - 2022-10-13 09:19:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 14:19:49 --> Severity: Notice --> Undefined variable: siswa C:\xampp\htdocs\sisy\application\views\master\verval_siswa.php 82
ERROR - 2022-10-13 14:19:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sisy\application\views\master\verval_siswa.php 82
ERROR - 2022-10-13 09:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:24:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:26:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:27:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:28:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:30:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:34:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:40:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:52:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:53:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:53:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:54:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 14:54:55 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-13 09:54:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:56:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 09:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:01:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:04:17 --> 404 Page Not Found: Laporan/index
ERROR - 2022-10-13 10:04:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:04:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:07:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:10:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:13:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:13:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:13:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:13:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:13:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:16:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:23:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:24:53 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-13 10:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:26:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:27:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:27:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:29:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:35:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:38:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:38:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:38:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:38:46 --> Severity: Warning --> Use of undefined constant verifikasi - assumed 'verifikasi' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sisy\application\controllers\admin\Master_siswa.php 324
ERROR - 2022-10-13 10:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:40:40 --> Severity: Warning --> Use of undefined constant verifikasi - assumed 'verifikasi' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sisy\application\controllers\admin\Master_siswa.php 324
ERROR - 2022-10-13 10:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:42:03 --> Query error: Unknown column 'admin_lock' in 'where clause' - Invalid query: SELECT *
FROM `dt_siswa`
JOIN `mt_provinsi` ON `mt_provinsi`.`id_provinsi` = `dt_siswa`.`provinsi_id`
JOIN `mt_kabupaten` ON `mt_kabupaten`.`id_kabupaten` = `dt_siswa`.`kabupaten_id`
WHERE `status` = 'null'
AND `lock` = 'Ylock'
AND `admin_lock` = 'Ylock'
ORDER BY `id_siswa` DESC
ERROR - 2022-10-13 10:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:43:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:44:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:44:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:44:08 --> Severity: Warning --> Use of undefined constant verifikasi - assumed 'verifikasi' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sisy\application\controllers\admin\Master_siswa.php 324
ERROR - 2022-10-13 10:44:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:44:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:46:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:47:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:47:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 15:47:22 --> Severity: Warning --> Use of undefined constant verifikasi - assumed 'verifikasi' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sisy\application\controllers\admin\Master_siswa.php 324
ERROR - 2022-10-13 10:47:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:47:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:48:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 10:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:00:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:18:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:26:31 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:27:41 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:27:41 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:27:42 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:27:42 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:27:42 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:01 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:02 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:02 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:02 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:03 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:03 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:03 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:37 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:38 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:38 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:28:41 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:29:32 --> 404 Page Not Found: admin/Data_siswa/index
ERROR - 2022-10-13 11:33:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:33:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:33:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:33:28 --> 404 Page Not Found: Excel-laporan/index
ERROR - 2022-10-13 11:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:32 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:47 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:48 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:48 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:49 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:49 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:49 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:34:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:34:49 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:14 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:15 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:35:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:18 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:55 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:56 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:56 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:35:56 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:02 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:02 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:03 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:03 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:03 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:03 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:04 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:36:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:36:04 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:37:44 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:37:45 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:37:45 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:37:47 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:37:49 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:38:56 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:38:58 --> 404 Page Not Found: Excel_laporan/index
ERROR - 2022-10-13 11:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:40:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:40:25 --> 404 Page Not Found: Export_pdf/index
ERROR - 2022-10-13 11:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:42:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:42:07 --> Severity: Warning --> fopen(./public/img/pancacita.png): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\application\third_party\fpdf\fpdf.php 1256
ERROR - 2022-10-13 16:42:07 --> Severity: error --> Exception: FPDF error: Can't open image file: ./public/img/pancacita.png C:\xampp\htdocs\sisy\application\third_party\fpdf\fpdf.php 271
ERROR - 2022-10-13 11:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 60
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: hari_presensi C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 61
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: tgl_presensi C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 62
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: waktu_presensi C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 63
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: lat C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 65
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: long C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 66
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: jarak C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 67
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: jarak C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 69
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: jarak C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 71
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: home_base C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 72
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: jarak C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 76
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: jarak C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 78
ERROR - 2022-10-13 16:42:31 --> Severity: Notice --> Undefined index: jarak C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 81
ERROR - 2022-10-13 16:42:31 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\third_party\fpdf\fpdf.php 271
ERROR - 2022-10-13 16:42:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\system\core\Common.php 571
ERROR - 2022-10-13 11:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:46:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:46:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:46:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:46:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:46:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:47:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:47:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:48:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:49:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:52:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:52:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:52:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:54:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:57:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:57:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:57:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:57:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:58:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:58:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 11:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:00:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:00:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:00:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:01:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:01:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:03:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 17:04:13 --> Severity: error --> Exception: syntax error, unexpected 'number_format' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 70
ERROR - 2022-10-13 12:04:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:04:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:05:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 17:06:45 --> Severity: Warning --> Use of undefined constant verifikasi - assumed 'verifikasi' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sisy\application\controllers\admin\Master_siswa.php 324
ERROR - 2022-10-13 12:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:06:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:07:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:07:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:07:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:08:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:10:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:12:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:12:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:12:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:13:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:14:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:15:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:15:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:15:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 12:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:02:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 18:02:09 --> Severity: Notice --> Undefined property: Data_siswa::$formulir C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 191
ERROR - 2022-10-13 18:02:09 --> Severity: error --> Exception: Call to a member function view() on null C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 191
ERROR - 2022-10-13 13:02:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:03:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:04:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'atas_nama' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'atas_nama' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:04:47 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:04:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 241
ERROR - 2022-10-13 18:04:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 242
ERROR - 2022-10-13 18:04:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 243
ERROR - 2022-10-13 13:05:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 241
ERROR - 2022-10-13 18:05:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 242
ERROR - 2022-10-13 18:05:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 243
ERROR - 2022-10-13 13:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:13 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:14 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 241
ERROR - 2022-10-13 18:05:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 242
ERROR - 2022-10-13 18:05:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 243
ERROR - 2022-10-13 13:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:15 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 241
ERROR - 2022-10-13 18:05:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 242
ERROR - 2022-10-13 18:05:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 243
ERROR - 2022-10-13 13:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_siswa' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 196
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nisn' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 197
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_sekolah' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 198
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_bank' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 199
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'no_rek' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 200
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nominal' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 201
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 202
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'kelas' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 203
ERROR - 2022-10-13 18:05:16 --> Severity: Notice --> Trying to get property 'nm_kabupaten' of non-object C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 204
ERROR - 2022-10-13 18:05:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 241
ERROR - 2022-10-13 18:05:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 242
ERROR - 2022-10-13 18:05:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\sisy\system\core\Exceptions.php:272) C:\xampp\htdocs\sisy\application\controllers\report\Data_siswa.php 243
ERROR - 2022-10-13 13:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:07:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:08:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:09:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:13:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:13:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:14:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:14:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:14:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:15:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:16:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:17:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-13 13:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
