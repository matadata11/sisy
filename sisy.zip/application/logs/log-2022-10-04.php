<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-04 06:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 11:30:57 --> Severity: Notice --> Undefined index: lock C:\xampp\htdocs\sisy\application\controllers\auth\Login.php 29
ERROR - 2022-10-04 06:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:36:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:36:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-04 06:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
