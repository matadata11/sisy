<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-29 10:38:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:38:40 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Error' does not have a method 'index' C:\xampp\htdocs\sisy\system\core\CodeIgniter.php 533
ERROR - 2022-09-29 10:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:02 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:44:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:03 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:04 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:04 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:05 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:44:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:09 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:21 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:22 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:44:22 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:29 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:30 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:30 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:31 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:31 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:31 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:31 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:32 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:45:32 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:39 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:39 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:40 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:40 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:40 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:40 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:53 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:53 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:54 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:54 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:54 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:54 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:54 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:46:55 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:46:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:47:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:02 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:38 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:38 --> Severity: Warning --> include(application/views/errorshtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:38 --> Severity: Warning --> include(): Failed opening 'application/views/errorshtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:57 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:57 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:57 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:57 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:57 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:57 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:58 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:58 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:58 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:58 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:58 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:58 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:58 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:58 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:58 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:59 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:59 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:59 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:47:59 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(application/views/errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:47:59 --> Severity: Warning --> include(): Failed opening 'application/views/errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:06 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:48:06 --> Severity: Warning --> include(errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:48:06 --> Severity: Warning --> include(): Failed opening 'errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:07 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:48:07 --> Severity: Warning --> include(errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:48:07 --> Severity: Warning --> include(): Failed opening 'errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:07 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:48:07 --> Severity: Warning --> include(errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:48:07 --> Severity: Warning --> include(): Failed opening 'errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:07 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 15:48:07 --> Severity: Warning --> include(errorhtml\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 15:48:07 --> Severity: Warning --> include(): Failed opening 'errorhtml\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\sisy\system\core\Exceptions.php 183
ERROR - 2022-09-29 10:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:33 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:33 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:33 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:48:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:34 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:48:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:48:34 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:47 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:47 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:48 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:48 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:49 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:49 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:51:49 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:04 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:05 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:05 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:05 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:05 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:06 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:06 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:06 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:06 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:10 --> 404 Page Not Found: Component-alert/index
ERROR - 2022-09-29 10:54:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 10:54:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:54:24 --> 404 Page Not Found: Component-collapsehtml/index
ERROR - 2022-09-29 10:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:55:35 --> 404 Page Not Found: Component-collapsehtml/index
ERROR - 2022-09-29 10:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:55:35 --> 404 Page Not Found: Component-collapsehtml/index
ERROR - 2022-09-29 10:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:55:35 --> 404 Page Not Found: Component-collapsehtml/index
ERROR - 2022-09-29 10:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:55:35 --> 404 Page Not Found: Component-collapsehtml/index
ERROR - 2022-09-29 10:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:55:36 --> 404 Page Not Found: Component-collapsehtml/index
ERROR - 2022-09-29 10:56:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:56:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:56:18 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:56:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:56:34 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:57:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:57:03 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:57:03 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:57:03 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:57:03 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 10:57:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 15:57:18 --> 404 Page Not Found: Component-dropdownhtml/index
ERROR - 2022-09-29 10:58:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:00:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:00:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:00:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:02:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:02:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:04:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:05:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:07:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:08:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:08:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:08:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:08:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:08:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:12:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:12:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:12:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:12:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:14:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:15:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-29 11:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:17:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:20:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:21:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:22:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:22:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:30:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:33:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:34:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:35:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:37:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:39:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:40:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:43:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:44:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:45:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:46:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:50:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:52:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:52:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:52:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:53:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:54:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:56:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 16:57:10 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-09-29 11:57:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:57:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 11:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:00:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:04:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:05:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:08:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:12:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:13:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:15:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:19:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:56:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:56:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:56:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 17:56:13 --> 404 Page Not Found: Assets/images
ERROR - 2022-09-29 12:56:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 17:56:13 --> 404 Page Not Found: Assets/images
ERROR - 2022-09-29 12:58:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 12:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:00:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 18:06:02 --> Severity: error --> Exception: Unable to locate the model you have specified: M_siswa C:\xampp\htdocs\sisy\system\core\Loader.php 349
ERROR - 2022-09-29 13:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:07:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:08:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:08:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:08:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 18:18:02 --> Severity: error --> Exception: syntax error, unexpected 'pages' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sisy\application\views\backend\main.php 147
ERROR - 2022-09-29 13:18:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 18:18:03 --> Severity: error --> Exception: syntax error, unexpected 'pages' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sisy\application\views\backend\main.php 147
ERROR - 2022-09-29 13:18:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:24:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:26:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:26:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:27:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:29:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:31:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:32:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:33:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:33:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:33:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:36:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:36:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:36:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:36:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:47:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-09-29 13:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
